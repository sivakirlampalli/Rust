fn main() {
    let my_tuple = (10, "Rust", 3.14);
    println!("Tuple: {:?}", my_tuple);
    println!("First element: {}", my_tuple.0);
    println!("Second element: {}", my_tuple.1);
}

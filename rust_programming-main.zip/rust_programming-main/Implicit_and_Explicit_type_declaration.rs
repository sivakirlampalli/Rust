fn main() {
    // a. Implicit type
    let a = 10.5;
    println!("Implicit: a = {} | type = f64", a);

    // b. Explicit type
    let b: i32 = 20;
    println!("Explicit: b = {} | type = i32", b);
}

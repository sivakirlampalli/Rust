fn main() {
    let mut x = 1000; // mutable variable
    let y = "Programming";

    println!("x = {}", x);
    println!("y = {}", y);

    x = 1100; // change value

    println!("After change:");
    println!("x = {}", x);
    println!("y = {}", y);
}
